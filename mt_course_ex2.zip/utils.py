import json
import os
from collections import Counter

import numpy as np
import seaborn as sns
import torch
from matplotlib import pyplot as plt

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


def prepare_sentence(line):
    return ['<s>', *line.strip().split(), '</s>']


def prepare_data(file_path):
    with open(file_path, 'r', encoding='utf-8') as data_file:
        return [prepare_sentence(line) for line in data_file]


def parse_input(source, target):
    source_data = prepare_data(source)
    target_data = prepare_data(target)

    return zip(source_data, target_data), source_data, target_data


# Filter non frequent words and return mapping from word to index and index to word
def convert_data_format(data):
    count = Counter(word for sentence in data for word in sentence)
    low_frequent_words = {word for word, amount in count.items() if amount <= 3}
    restricted_data = [['<?>' if word in low_frequent_words else word for word in sentence] for sentence in data]
    words_set = set(word for sentence in restricted_data for word in sentence)
    tokens = ['<?>', '<s>', '</s>']
    words = tokens + sorted(word for word in words_set if word not in tokens)

    word_to_index = {}
    index_to_word = {}
    for i, word in enumerate(words):
        word_to_index[word] = i
        index_to_word[i] = word

    return word_to_index, index_to_word


def get_index(word_to_index, word):
    return word_to_index[word] if word in word_to_index else word_to_index['<?>']


def data_to_index(data, source_to_index, target_to_index):
    source_dictionary = []
    target_dictionary = []
    for source, target in data:
        source_dictionary.append([get_index(source_to_index, word) for word in source])
        target_dictionary.append([get_index(target_to_index, word) for word in target])

    return source_dictionary, target_dictionary


def to_tensor(indexes):
    return list(map(torch.LongTensor, indexes))


def print_epoch(epoch, train_loss, dev_loss, bleu_score):
    print(f'Epoch: {epoch}\t'
          f'Train Loss: {train_loss:.3f}\t'
          f'Dev Loss: {dev_loss:.3f}\t\t'
          f'BLEU Score: {bleu_score:.3f}')


def shuffle_data(*args):
    c = list(zip(*args))
    np.random.shuffle(c)
    return zip(*c)


def write_epoch(decoder_attentions, epoch, directory, file_name):
    with open(directory + file_name, 'a+', encoding='utf-8') as file:
        file.write('Epoch {}:\n'.format(epoch))
        for attention in [attention.tolist()[0] for attention in decoder_attentions]:
            json.dump(attention, file)
            file.write('\n')
        file.write('\n')


def create_heatmap(decoder_attentions, epoch, dev_source_example, dev_source_example_txt, dev_target_example_txt,
                   directory):
    figure, axes = plt.subplots(1, figsize=(8, 8), dpi=192)
    figure.subplots_adjust(left=0, right=1, bottom=0, top=1)
    axes.set_xticks(np.arange(len(dev_source_example_txt[1:dev_source_example.size(0) - 1]) + 2))
    axes.set_yticks(np.arange(len(dev_source_example_txt[1:dev_source_example.size(0) - 1]) + 1))
    axes = sns.heatmap(torch.cat(decoder_attentions, dim=0).numpy(), square=True, cmap="Blues",
                       xticklabels=['begin'] + dev_source_example_txt[1:dev_source_example.size(0) - 1] + ['end'],
                       annot=True, cbar=False)
    axes.set_yticklabels(dev_target_example_txt[1:dev_source_example.size(0) - 1] + ['end'], rotation=360)
    axes.set(title="Attention-based Alignment:\n{0} -> {1}\n".format(' '.join(
        dev_source_example_txt[1:dev_source_example.size(0) - 1]), ' '.join(
        dev_target_example_txt[1:dev_source_example.size(0) - 1])),
        xlabel="Input",
        ylabel="Output")
    figure.tight_layout()
    plt.savefig(directory + '/Epoch_' + str(epoch) + '.png', dpi=192, bbox_inches='tight')

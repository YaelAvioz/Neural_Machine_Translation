# Part 3 - Analysis

#### Analysis Script

To Run the analysis script you should have the following files:
analysis.py , utils.py

Script Path: MT_ex2\Analysis\analysis.py

Parameters:
1. train.src - source train file
2. train.trg - target train file
3. dev.src - source dev file
4. dev.trg - target dev file

For example:
python3 analysis.py ..\Data\train.src ..\Data\train.trg ..\Data\dev.src ..\Data\dev.trg

Output files:
1. 10 Heatmap Plots images
2. weights.json
